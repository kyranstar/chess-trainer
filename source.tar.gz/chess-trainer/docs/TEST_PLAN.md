# Test plan and quality gates

## Rules and puzzles
- Parse and replay FEN/PGN and all source lines with mature rules engine; make/fork/undo, legal promotion options, castling through check rejected, en passant, repetition, stalemate, checkmate, legal move alternatives.
- Lichess puzzle source: apply source-specific setup move first when required, verify side to solve, enumerate accepted chess-equivalent continuations where appropriate, preserve source puzzle ID.
- Endgame fixture: tablebase exact result before/after each reviewed move; handle underpromotions and multi-solution draws/wins.
- Repertoire transpositions give same canonical position under different legal move orders; maintain correct instructional source contexts.

## Learning pipeline
- Diagnostic with insufficient evidence shows Untested, not 0% mastery.
- New-learning budget remains protected despite review backlog.
- Linked course opened ≠ completed; explicit manual completion and independent assessment are distinct records.
- Failed and successful first attempts, hints and repeated attempts have correct labels; delayed review doesn't inflate fresh-solving metric.
- Review schedule deterministic under fixed time and replayable logs; version change preserves source events.

## Game analysis & metrics
- Import same PGN twice is idempotent, including different encodings and archive refreshes.
- Analyze engine fixture with perspective-consistent evaluations, reproducible engine metadata, explicit coverage and no ungrounded causal labels.
- Metric tests use fixture game data: major-error denominator, missing clocks, mismatched time controls, excluded unanalyzed games, low n, WDL perspective, engine-version changes.
- Every dashboard card shows sample size/period/scope and opens exactly the source games/attempts underlying the aggregate.

## Mobile/reliability
- iPhone installed PWA loads offline with previously downloaded pack; imported answers survive force quit/reopen and update.
- No mandatory remote network requests during a 30-minute session. Offline linked courses clearly unavailable; practice fallback continues.
- Export full user-owned data to JSON/ZIP with schema version; reimport into clean device reproduces attempts, review due dates and dashboard derived values.
- Corrupted import shows error and does not damage existing data; migrate old schema successfully.
- Navigation, board taps, voiceover labels, color contrasts, move feedback, portrait/landscape; avoid excessive scrolling for main session.
- The result as moves (ADR-052, `e2e/games.spec.ts`, `e2e/layout.spec.ts`): after an own-game answer the board shows the position asked with one arrow per move; chips You / Game / Best in that order, merged when the same move; each bar carries the expected score; a tapped line plays to where it is decided, each move can be gone back to and one step before the first is the position asked; the mark and the ring appear on the learner's own move; nothing scrolls at 390 by 664; a solved puzzle can be stepped back through; the control in the bar returns the previous position exactly as left, with one exercise in the document, and its main button does not advance the run.
- Nothing before, everything after, and the engine's other choices (ADR-054, `src/chess/line.test.ts`, `e2e/games.spec.ts`, `e2e/layout.spec.ts`, `e2e/learn-flow.spec.ts`, `e2e/offline.spec.ts`): a question names neither the concept nor the game; the source and the themes appear with the result; every compared move and every other move carries the engine's number; the other moves are never one of the chips, are in order of their numbers and at most three; a tapped one plays in its own colour and its moves take the row's place; nothing scrolls at 390 by 664 at rest or with a line open; a wrong puzzle move carries its number and the solution's is higher.
- The result as a board to analyse on (ADR-055, `src/chess/line.test.ts`, `e2e/games.spec.ts`, `e2e/layout.spec.ts`): what a move made by hand does (one step on, an existing line opened, a line tried), for either side; the tried move as the chip "Try" with its number from the learner's side, named with its move number when made later than the position asked; the engine's reply played on the board and its line written; moves made by hand marked; the chip returning to the position asked and staying; a mated position not movable; nothing recorded; nothing scrolls at 390 by 664.
- Review asks what was missed (ADR-056, `src/games/reviewItem.test.ts`, `e2e/games.spec.ts`): every "Your move" position the session can ask is found again by its id; a position whose question is gone is asked as "Your move"; a missed position is first in the next day's review on the position asked; a due item that is not on the device is not announced, is marked gone and is not due again.
- Exercise layout (ADR-051, `e2e/layout.spec.ts`): the board's place and size are the same through question, wrong move, replay, solution and the next position; the main button is in one place; nothing scrolls while a position is being asked; the flip control in the bar turns the board. The churn suite starts watching for unwanted movement only once a line that plays itself has come to rest.

## Accounts (ADR-063)
- Server rules on the local emulator (`npm run test:rules`, needs Java, no cloud): `firebase/rules.test.ts` (every collection and role: admin, invited, not invited, removed, unverified, another account) and `firebase/service.test.ts` (the app's own Firebase service: sign-in, the access answer, the profile, the copy written and read through the rules with a conflict on a stale revision, the admin's calls).
- Unit: settings with change times travel and removals win (`src/db/stamps.test.ts`); the account copy in chunks, merge before write, nothing sent twice, a damaged chunk refused, a newer copy held back (`src/account/copy.test.ts`); which database an account uses and the old one to the admin only (`src/account/device.test.ts`); the greeting; screen flags (`src/db/screenFlag.test.ts`).
- Browser, on the stand-in account service (`e2e/accounts.spec.ts`, both browsers): not on the list; hello, Chess.com found and confirmed, greeting, straight to Today on reload; skipping Chess.com; install first on an iPhone; offline open once allowed; a second device gets the progress; the admin invites and removes; a friend sees no flag, GitHub copy, courses or admin page; unlinking Chess.com; a flag with a note on any screen. Every other browser test runs in local mode, unchanged.

## Cost/security
- Network capture verifies no personal data uploaded in local-only mode. No third-party credential collection, logs sanitized, HTTPS for static hosting.
- App builds and tests in clean workspace with no cloud credentials, API keys or paid accounts.
