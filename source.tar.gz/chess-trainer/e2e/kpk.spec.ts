import { expect, type Page, test } from '@playwright/test';
import { legalDests, positionFromFen } from '../src/chess/rules';
import { openApp, playMove } from './helpers';

let cancelTried = false;

/** Plays the drill on screen with table-perfect moves until it ends. */
async function playPerfectly(page: Page) {
  const drill = page.getByTestId('kpk-drill');
  for (let i = 0; i < 45; i++) {
    if ((await drill.getAttribute('data-done')) === 'true') return;
    await expect(drill).not.toHaveAttribute('data-keeping', '');
    const goal = await drill.getAttribute('data-goal');
    const move = goal === 'win' ? (await drill.getAttribute('data-fastest'))! : (await drill.getAttribute('data-keeping'))!.split(' ')[0]!;
    const before = await drill.getAttribute('data-fen');
    if (move.length === 5 && !cancelTried) {
      // Start the promotion, cancel the piece choice: the pawn goes back and the board stays playable.
      cancelTried = true;
      await playMove(page, move.slice(0, 4));
      await page.getByTestId('promo-cancel').click();
      await expect(drill).toHaveAttribute('data-fen', before!);
      await expect(page.locator('.board').first()).not.toHaveAttribute('data-movable', 'none');
    }
    await playMove(page, move);
    await expect(drill).not.toHaveAttribute('data-fen', before!);
    // wait for the reply (or the end)
    await expect(async () => {
      const done = (await drill.getAttribute('data-done')) === 'true';
      const keeping = await drill.getAttribute('data-keeping');
      expect(done || keeping !== '').toBeTruthy();
    }).toPass();
  }
  throw new Error('play-out did not end');
}

test('king and pawn ending: win against best defence, hold a draw, and a result-changing move is named exactly', async ({ page }) => {
  await openApp(page, '#/practice/run?mode=kpk');
  const drill = page.getByTestId('kpk-drill');

  // 1. Win it: best play queens the pawn; the verdict comes from the table.
  await expect(drill).toHaveAttribute('data-goal', 'win');
  await expect(drill).toContainText('Best play needs');
  await playPerfectly(page);
  await expect(page.getByTestId('kpk-verdict')).toHaveAttribute('data-ok', 'true');
  await expect(page.getByTestId('kpk-verdict')).toContainText('queened safely');
  await page.getByTestId('kpk-next').click();

  // 2. Hold it: ten correct defensive moves (or the pawn falls, or stalemate).
  await expect(drill).toHaveAttribute('data-goal', 'hold');
  await playPerfectly(page);
  await expect(page.getByTestId('kpk-verdict')).toHaveAttribute('data-ok', 'true');
  await page.getByTestId('kpk-next').click();

  // 3. Win it, but play a legal move that is not the one winning move: the table says so at once.
  await expect(drill).toHaveAttribute('data-goal', 'win');
  const fen = (await drill.getAttribute('data-fen'))!;
  const keeping = (await drill.getAttribute('data-keeping'))!.split(' ');
  expect(keeping).toHaveLength(1);
  const pos = positionFromFen(fen);
  const wrong = [...legalDests(pos)].flatMap(([from, tos]) => tos.map((to) => `${from}${to}`)).find((u) => !keeping.includes(u) && !/[18]$/.test(u))!;
  await playMove(page, wrong);
  const verdict = page.getByTestId('kpk-verdict');
  await expect(verdict).toHaveAttribute('data-ok', 'false');
  await expect(verdict).toContainText('theoretical draw');
  await expect(verdict).toContainText(/Only \S+ kept the win\./);
  // The same start can be tried again at once. The second go is practice: Progress below
  // still counts three play-outs, one of them missed.
  await page.getByTestId('kpk-retry').click();
  await expect(drill).toHaveAttribute('data-done', 'false');
  await expect(drill).toHaveAttribute('data-fen', fen);
  await playMove(page, wrong);
  await expect(page.getByTestId('kpk-retry-note')).toContainText('not recorded');

  // Progress reports the three play-outs with their split, separately from puzzles.
  await page.goto('./#/progress/more/endgames');
  const card = page.getByTestId('card-endgame');
  await expect(card).toContainText('2 of 3');
  await expect(card).toContainText('Winning: 1 of 2. Holding the draw: 1 of 1.');
  await page.goto('./#/progress');
  await expect(page.getByTestId('card-unseen').getByTestId('insufficient')).toBeVisible();
  // Only the ending that went wrong is kept for review; the two played correctly are not.
  await page.goto('./#/practice');
  await expect(page.getByTestId('practice-review')).toContainText('1 in the queue');
});

test('the opposition is demonstrated by playing five unseen endings correctly, not by tagged puzzles', async ({ page }) => {
  await openApp(page, '#/learn/endgame.opposition');
  await expect(page.getByTestId('concept-evidence')).toHaveText('Untested');
  await page.getByTestId('start-check').click();
  for (let i = 0; i < 5; i++) {
    await expect(page.getByTestId('run-note')).toHaveText(`Check ${i + 1} of 5`);
    await expect(page.getByRole('button', { name: 'Show the answer' })).toHaveCount(0);
    await playPerfectly(page);
    await page.getByTestId('kpk-next').click();
  }
  await expect(page.getByTestId('check-result')).toHaveAttribute('data-passed', 'true');
  await page.getByTestId('check-done').click();
  await expect(page.getByTestId('concept-stage')).toHaveText('Learned by pre-test');
  await expect(page.getByTestId('concept-evidence')).toContainText('5 of 5 endings played out correctly first time');
});
